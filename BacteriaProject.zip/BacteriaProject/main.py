import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Create directories "input" and "images" if they do not already exist
os.makedirs("input", exist_ok=True)
os.makedirs("images", exist_ok=True)

# Place CSV files in the "input" folder for processing
for file_name in os.listdir("input"):
    if file_name.endswith(".csv"):  # Process only CSV files
        file_path = os.path.join("input", file_name)  # Full path of the CSV file
        data = pd.read_csv(file_path, delimiter=";")  # Read the CSV file using ';' as a delimiter

        print(f"Processing file: {file_name}")  # Log the name of the current file
        print("Columns in dataset:", data.columns)  # Display the columns present in the dataset

        # Check if the required column exists; if not, raise an error
        if 'counts_live_bacteria_per_wet_g' not in data.columns:
            raise KeyError(f"Column 'counts_live_bacteria_per_wet_g' not found in the dataset for file: {file_name}")

        # Calculate the log10 transformation of bacterial counts
        data["log10_counts_live_bacteria"] = np.log10(data["counts_live_bacteria_per_wet_g"])

        # Filter data for fecal samples and define washout start and end days
        fecal_data = data[data["sample_type"] == "fecal"]
        washout_start, washout_end = fecal_data["experimental_day"].min(), fecal_data["experimental_day"].max()
        washout_data_filtered = fecal_data[(fecal_data["experimental_day"] >= washout_start) &
                                           (fecal_data["experimental_day"] <= washout_end)]

        # Plot the line chart for fecal sample data during the washout period
        plt.figure(figsize=(10, 6))
        sns.lineplot(
            data=washout_data_filtered,
            x="experimental_day",
            y="log10_counts_live_bacteria",
            hue="treatment",  # Differentiate lines by treatment group
            style="mouse_ID",  # Differentiate styles by mouse ID
            palette={"placebo": "blue", "ABX": "orange"},  # Define colors for treatments
            markers=True,  # Use markers for data points
            dashes=False,  # Solid lines
            legend=False  # Disable automatic legend
        )
        plt.title(f"Log10(Live Bacteria per Wet Gram) vs. Washout Day ({washout_start} to {washout_end})")
        plt.xlabel("Washout Day (Experimental Day)")
        plt.ylabel("Log10(Live Bacteria per Wet Gram)")
        plt.legend(
            handles=[
                plt.Line2D([0], [0], color="blue", lw=2, label="Placebo"),
                plt.Line2D([0], [0], color="orange", lw=2, label="ABX"),
            ],
            title="Treatment",
            loc="upper left"
        )
        # Save the plot to the "images" folder with a file name based on the CSV file
        plt.savefig(f"images/{file_name.split('.')[0]}_fecal_plot.png")
        plt.close()

        # Plot the violin plot for ileal sample data
        ileal_data = data[data["sample_type"] == "ileal"]
        plt.figure(figsize=(8, 6))
        sns.violinplot(
            data=ileal_data,
            x="treatment",
            y="log10_counts_live_bacteria",
            palette={"placebo": "blue", "ABX": "orange"},  # Define colors for treatments
            inner="point"  # Show individual data points
        )
        plt.title("Log10(Live Bacteria per Wet Gram) by Treatment (Ileal)")
        plt.xlabel("Treatment")
        plt.ylabel("Log10(Live Bacteria per Wet Gram)")
        # Save the violin plot to the "images" folder
        plt.savefig(f"images/{file_name.split('.')[0]}_ileal_plot.png")
        plt.close()

        # Plot the violin plot for cecal sample data
        cecal_data = data[data["sample_type"] == "cecal"]
        plt.figure(figsize=(8, 6))
        sns.violinplot(
            data=cecal_data,
            x="treatment",
            y="log10_counts_live_bacteria",
            palette={"placebo": "blue", "ABX": "orange"},  # Define colors for treatments
            inner="point"  # Show individual data points
        )
        plt.title("Log10(Live Bacteria per Wet Gram) by Treatment (Cecal)")
        plt.xlabel("Treatment")
        plt.ylabel("Log10(Live Bacteria per Wet Gram)")
        # Save the violin plot to the "images" folder
        plt.savefig(f"images/{file_name.split('.')[0]}_cecal_plot.png")
        plt.close()
